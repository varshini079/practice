package com.oops.encapsulation;

public class Student {
    private String name;
    private int roll;
    private boolean isPresent;

    public Student(){
       
    }
    public void setName(String name){
        this.name=name;
    }
    public String getName() {
        return name;
    }
    public void setisPresent(boolean isPresent) {
        this.isPresent = isPresent;
    }
    public int getRoll() {
        return roll;
    }
    public boolean getisPresent() {
        return isPresent;
    }
    public void setRoll(int roll){
        this.roll=roll;
    }
    public String student(){
        return "details";
    }
}
