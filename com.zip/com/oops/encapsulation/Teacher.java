package com.oops.encapsulation;
public class Teacher {
    public static void main(String args[]){
    Student s= new Student();
    s.setRoll(24);
    s.setisPresent(true);
    s.setName("shiva");
    System.out.println(s.getName() +" "+s.getRoll()+" "+ s.getisPresent() +" "+s.student());}
}
