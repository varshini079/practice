package com.oops.polymorphism;

class MethodOverloading {
    public int add(int a, int b) {
        return a + b;
    }
    public double add(double a, double b) {
        return a + b;
    }
    public int add(int a, int b, int c) {
        return a + b + c;
    }
    public double add(int a, double b) {
        return a + b;
    }
    public double add(double a, int b) {
        return a + b;
    }
}
class Methods {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        MethodOverloading mo = new MethodOverloading();
        System.out.println("Sum of 2 integers: " + mo.add(5, 10));
        System.out.println("Sum of 2 doubles: " + mo.add(5.5    , 10.5));
        System.out.println("Sum of 3 integers: " + mo.add(5, 10, 15));
        System.out.println("Sum of int and double: " + mo.add(5, 10.5));
        System.out.println("Sum of double and int: " + mo.add(5.5, 10));
        System.out.println("Sum of int and double: " + mo.add(5, 10.5));
    }
}
//MethodOverloading is same method with different numbers of parameters
// or different types of parameters when number of parameters is same.

// #1
// It is not compulsory that a class should have methods and variables. It will be empty also.
// The parameters that except the values in a method should be equal to the parameters that we pass in a method to call it.
// As it might create a problem if the parameters excepted by the method are not equal to the number of values passed.
// So, to overcome this problem we do overloading.
// As we can have two methods we the same name but different parameters.
// Either the number of parameters or the type of parameters should be different.
// Method with the same name and parameters but with different return types will also not work. The return type does not matter here. Method name and parameters matter only.

// #2
// Method overloading:- In Java, there can be more than one method with the same name but the number of parameters or type of parameters should be different.

// Method overloading is also known as Compile-time Polymorphism, Static Polymorphism, or Early binding in Java.
// In Method overloading compared to parent argument, child argument will get the highest priority.
// #3
// Different ways of Method Overloading in Java:-
// 1. Changing the number of parameters
// Method overloading can be achieved by changing the number of parameters while passing to different methods.

// 2. Changing Data Types of the Parameters
// If methods have the same name but have different parameter types then also methods are considered as overloaded.

// 3. Changing the Order of the Parameters of Methods
// By rearranging the parameters of two or more overloaded methods. 
