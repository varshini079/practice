package com.userdefinedpackage;
import java.util.*;
public class OOPStudentDemo {
    public static void main(String[] args) {

        // (Encapsulation)
        Student s1 = new Student();
        s1.setName("Varshini");
        s1.setAge(22);
        s1.setCompany("Cognizant");

        System.out.println("=== Student Details ===");
        s1.displayDetails();

        // Creating a cts object (Inheritance + Abstraction + Polymorphism)
        cts dev = new cts();
        dev.showCompany(); // from abstract class
        dev.work();         // overridden method
    }
}

abstract class Company {
   String companyName;

    Company(String companyName) {
        this.companyName = companyName;
    }

    public abstract void work();

    public void showCompany() {
        System.out.println("Company: " + companyName);
    }
}

// 2 Encapsulation:
class Student {
    private String name;
    private int age;
    private String company;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age > 0)
            this.age = age;
        else
            System.out.println("Invalid age!");
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public void displayDetails() {
        System.out.println("Student Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Company: " + company);
    }
}

// 3 Inheritance: cts is a type of Company
class cts extends Company {
     cts() {
        super("cts"); // passes company name to parent constructor
    }

    @Override
    public void work() { // Polymorphism (method overriding)
        System.out.println(companyName+" works on building software" );
    }
}

