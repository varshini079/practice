package com.userdefinedpackage.datatypeandcontrolstat;

class Static{
    static int y=10;
    int x=20;
    static{
        
        System.out.println("Static Block");
        System.out.println("Executed before main " );  //+x is wrong
        // Static obj=new Static();
        // System.out.println(obj.x);

    }

    {
        //non static block
        // static int b=20; wrong
        System.out.println("Non static block executed before the execution of constructor "+y);
    }
    Static(){
        System.out.println("constructor" +x);

    }
    public static void main(String []args){
        System.out.println("main method");
        Static c = new Static(); //non static block executed when we create object 
                System.out.println(c.x);

        // Help h ; -- this will not execute static block of Help class
        Help h = new Help(); //this will execute static block of Help class
        Help.wish(); //-- this will execute static block of Help class

    }
}
class Help{
    static {
        System.out.println("Static block of Help class");
    }
    static void wish(){
        System.out.println("Hello");
    }
}

