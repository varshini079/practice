package com.userdefinedpackage.datatypeandcontrolstat;

public class variable {
    // Instance variable
    String name;
    int age;
    static String edu;
    void showDetails() {
        // Local variable
        String course = "Java";
        System.out.println(name + " (" + age + ") is learning " + course +" "+edu);
    }

    public static void main(String[] args) {
        // Create object
        variable s1 = new variable();
        s1.name = "Varshini";  // accessing instance variable using object
        s1.age = 22;
        s1.edu="btech";
        System.out.println(variable.edu+" "+s1.edu);
        s1.showDetails();  // calling method using object
    }
}

