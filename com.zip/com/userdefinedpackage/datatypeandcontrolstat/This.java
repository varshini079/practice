package com.userdefinedpackage.datatypeandcontrolstat;

public class This {
    public static void main(String[] args) {
        Human obj1=new Human();
    // obj1.setAge(30,obj1);
        obj1.setAge(30);

    obj1.getAge();
    System.out.println(obj1 +" "+obj1.getAge());
    }
    

}
 class Human{
    private int age;
//    public void setAge(int a){
//     age=a;

//    }
//    public void setAge(int age){
//     age=age; //confusion starts
//    }
//   public  void setAge(int age,Human obj){
//     // Human obj1=obj;
//     obj.age=age;
//   }
public void setAge(int age){
    this.age=age;
}
   public int getAge(){
    return age;
   }

}

//this  is current obj reference 