package com.userdefinedpackage.datatypeandcontrolstat;

import java.util.Scanner;

public class datatype {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        System.out.println("Hello " + name);
        //take input from user  in integer
        System.out.println("Enter two numbers: ");
        int a = sc.nextInt();
        int c = sc.nextInt();
        System.out.println("You entered: " + a+" and "+c +"sum is "+(a+c));

        //take input from user in float
        // float b = sc.nextFloat();
        // System.out.println("You entered: " + b);
        //simple if and else
        if (a > c) {
            System.out.println(a + " is greater than " + c);
        } else {
            System.out.println(c + " is greater than " + a);
        }
        //nested if else
        if (a > c) {
            System.out.println(a + " is greater than " + c);
        } else if (a == c) {
            System.out.println(a + " is equal to " + c);
        } else {
            System.out.println(c + " is greater than " + a);
        }
        //for loop
        for (int i = 0; i < 5; i++) {
            System.out.println("Hello World");
        }
        //while loop
        int i = 0;
        while (i < 5) {
            System.out.println("Hello World");
            i++;
        }
        //array
        int[] arr = new int[5];
        //array creation 
         int[] array = {1, 2, 3};
        for (i = 0; i < 5; i++) {
            arr[i] = sc.nextInt();
            System.out.println("You entered: " + arr[i]);
        }
        sc.close();

      var num=   1;
    }
}
