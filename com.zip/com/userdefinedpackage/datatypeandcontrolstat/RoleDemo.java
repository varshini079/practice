package com.userdefinedpackage.datatypeandcontrolstat;

import java.util.Scanner;

public class RoleDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your role (PA, Associate, Manager): ");
        String role = sc.nextLine();


        if (role.equalsIgnoreCase("PA")) {
            System.out.println("Programmer Analyst");
        } else if (role.equalsIgnoreCase("Associate")) {
            System.out.println(" Associate Employee.");
        } else if (role.equalsIgnoreCase("Manager")) {
            System.out.println("Manager");
        } else {
            System.out.println("Role not recognized");
        }

 
        System.out.print("\nEnter years of experience: ");
        int exp = sc.nextInt();

        if (exp >= 0) {
            if (exp < 2) {
                System.out.println(" Junior in your role.");
            } else if (exp <= 5) {
                System.out.println("Mid-level in your role.");
            } else {
                System.out.println("Senior in your role.");
            }
        } else {
            System.out.println("Experience cannot be negative!");
        }


        System.out.print("\nEnter your department (1-HR, 2-Finance, 3-Operations): ");
        int dept = sc.nextInt();

        switch (dept) {
            case 1:
                System.out.println(" HR Department.");
                break;
            case 2:
                System.out.println("Finance Department.");
                break;
            case 3:
                System.out.println("Operations Department.");
                break;
            default:
                System.out.println("Invalid department!");
        }

        for (int i = 1; i <= 3; i++) {
            System.out.println("Task " + i );
        }

       
        int progress = 0;
        while (progress <= 100) {
            System.out.println("Progress: " + progress);
            
            if (progress == 50) {
                System.out.println("Half done ");
            }
            progress += 25;
        }

        char repeat;
        do {
            System.out.println("another task? (y/n): ");
            repeat = sc.next().charAt(0);

            if (repeat == 'y' || repeat == 'Y') {
                System.out.println("new tak");
            } else {
                System.out.println("exit");
                break; 
            }

        } while (true);

    }
}

