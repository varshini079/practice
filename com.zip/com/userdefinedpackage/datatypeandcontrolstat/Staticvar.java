package com.userdefinedpackage.datatypeandcontrolstat;


public class  Staticvar {
    public static void main(String[] args) {
        Mobile mobile1 = new Mobile();
        mobile1.model = "Galaxy S21";
        mobile1.brand = "Samsung";
        Mobile.name = "Smartphone"; // same for all objects 

        Mobile mobile2 = new Mobile();
        mobile2.model = "iPhone 13";
        mobile2.brand = "Apple";

        mobile2.name = "Handset"; // change name for all objects
        // Displaying information for both mobiles
        mobile1.display(); // Output: Model: Galaxy S21, Brand: Samsung, Name: Handset
        mobile2.display(); // Output: Model: iPhone 13, Brand: Apple, Name: Handset
        Mobile.display2(mobile1); //class access but obj is passed obj access is also there
        System.out.println(demo.a );
        demo.display1();

    }
}
class demo{
    static int a=10;
    static String str;
    static void display1(){
        System.out.println("in static method");
    }
    static{
        System.out.println("in static block");
    }
//     public static void main(String args[]){
//         System.out.println("main");
//         str="4";
//         System.out.println(demo.a+" "+str);
// //  direct access 
//     }
}
class Mobile{
    String model;
    String brand;
    static String name;
    public void display() {
        System.out.println("Model: " + model+", Brand: " + brand +", Name: " + name);
       
    }
    public static void display2(Mobile obj){
                System.out.println("Model: " + obj.model+", Brand: " + obj.brand +", Name: " + name);

    }
}



// #1
// Use of static keyword
// = when we are using static keyword with variable, block, method it become
// independent of object. 
// e.g class{
//     static int a=5;
// }
// = a is not dependent on object .if we have two object obj1 and obj2 then both object able to access this 
// variable.
// =when we are using static it become independent to object.

// #2
// Four place we can use static keyword 
// a) before variable declaration e.g class Calc{ static int s; }

// b) before a block  class Calc{  static {System.out.println("this is static block);}}

// c) during method creation class Calc{public static void add(int num1,int num2){};}

// d) with concept of inner class (It is not discussed in this lecture) 
// class OuterClass {
//   int x = 10;

//   static class InnerClass {
//     int y = 5;
//   }
// }

// #3
// When memory get allocated
// = for that we need to know some term 
// a)stack area b)heap area c)class loader system 
// Step 1: when you compile the code you get .class file 
// Step 2: when you are executing (java MainClass) first class loading to class loader System.
// Step 3: During class loading static variable initialize, static block get executed.
// Step 4: Since, static variable got memory in heap before object creation. Now we can say that it is independent of object.

// #4
// Static variable vs instance variable

// Class Calc{
//     static int stA=100; //independent of object // we can use this by class name as well as object
//     int  inB=100;  //dependent of object //we can only use this by object

// public static void main(String []args){
// Calc obj1=new Calc(); 
// Calc obj2=new Calc();
// //for static variable
// System.out.println(Calc.stA); //use with class name
// System.out.println(obj1.stA);  //use by object name

// //for instance variable
// //System.out.println(Calc.inB); //got an error --Cannot make a static reference to the non-static
// System.out.println(obj1.inB); //used by object name reference 


// // = if we can change value static or instance what happen 
// obj1.inB=1000;
// obj1.stA=2000;

// //static 
// System.out.println(obj1.stA);//output: 2000
// System.out.println(obj2.stA);//output: 2000 value changed for both obj1 and obj2 
// //it also show that static variable independent of objects

// //instance 
// System.out.println(obj1.inB); // output: 1000
// System.out.println(obj2.inB); // output: 100 no change in obj2
// }
// }

// #5
// static block vs non static block
// = remember static block executed before the execution of static method 
// = non static block executed when you try to create the object and executed before constructor called.



// #6
// Static method vs non static method
// = remember we can call static method with object reference or class name  e.g ClassName.staticMethod() or objReference.statiMethod()
// = but non static method dependent on object so it can be called only  by object reference. e.g objReference.nonStaticMethod();

// Remember one thing:
// i)we can use static property, member inside non static block or method without object creation.
// ii) But we cannot use non static property or method inside static block or method without object creation.