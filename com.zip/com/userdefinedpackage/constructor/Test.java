package com.userdefinedpackage.constructor;


public class Test {
      int x;
      public Test()  // Constructor with no arguments
      {
    	 System.out.println("Constructor with no arguments");
    	 x=10;
      }
	public static void main(String[] args) {
		Test t=new Test();  // Object Creation
		System.out.println(t.x);
	}

}